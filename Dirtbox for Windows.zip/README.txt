Dirtbox v3.1
Windows x86-64

Run dirtbox.exe. No installation is required.
Keep dirtbox-updater.exe and SDL2.dll beside dirtbox.exe.

The original Dirtbox world is embedded and opens on startup.
RESET or cycling back to DIRTBOX restores it. The Haunted world is separate.
Press N to cycle worlds and W to cycle weather.

Updates:
The itch app updates automatically through its Windows channel.
For direct downloads, the built-in updater activates when update-url.txt beside
the game contains the public manifest URL supplied with the release.
Press V or Check for updates. A downloaded update installs when you exit.
Your dirtbox-world.dbx save and update-url.txt settings are preserved.

Discord Rich Presence shows the current world, particle count or paused/guide
state, and elapsed time when the Discord desktop app is running.
The optional Discord art asset key is dirtbox.

Controls:
  Left mouse: draw       Right mouse: erase
  Mouse wheel: brush size
  H: field guide         Space: pause
  N: next world          R: reset
  W: next weather        V: check for updates
  F5 / Ctrl+S: save      F9 / Ctrl+O: load
  F11: fullscreen        Esc: close guide / quit

Saves are written as dirtbox-world.dbx in the current working directory.
The included default-world.dbx is a reference copy; the game does not need it.

Build: SDL2 2.32.4 / MinGW-w64 GCC 14, 64-bit GUI executable.
The updater is a self-contained Go executable.
