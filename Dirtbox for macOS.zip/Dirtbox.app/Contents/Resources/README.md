# Dirtbox v3.1

A private SDL2 falling-sand sandbox for Windows, macOS, Linux, and browsers.
The C++17 game and procedural art/audio need no external assets. The desktop
update helper uses Go's standard library and needs no runtime dependencies.

## What is new in v3.1

### Eight new materials, 100 playable materials total

- **Ectoplasm:** a cold, glowing spectral liquid
- **Bone:** powder that burns to ash and can be used to raise ghosts
- **Candy:** dissolves in water, melts into resin, and attracts ants
- **Pumpkin:** heat or a possessing wisp turns it into a jack-o-lantern
- **Jack-o-lantern:** a persistent warm light that water extinguishes
- **Wisp:** a drifting cold spirit with several transformations
- **Shadow:** a dark gas dispelled by nearby light
- **Blood:** freezes, chars, feeds mold, and can summon ghosts with ectoplasm

Every earlier material ID is unchanged. Old DBX3 saves still load.

### New reactions

- Ectoplasm + Bone, Blood, or Life = Ghost
- Ectoplasm + Heat = Wisp
- Pumpkin + Heat or Wisp = Jack-o-lantern
- Jack-o-lantern + Water = Pumpkin + Steam
- Wisp + Fire = Ghost
- Wisp + Shadow = Ectoplasm
- Jack-o-lantern, fire, lightning, lava, sunstone, or a lit lamp dispels Shadow
- Candy + Water = dissolved candy
- Candy + Heat = Resin
- Bone + Heat = Ash
- Blood + Cold = Ice
- Blood + Heat = Char + Smoke
- Mold + Blood = more Mold
- Ants eat Candy as well as seeds, plants, and leaves

### Haunted world and weather

The sixth world is a separate haunted house and graveyard with pumpkins,
bones, candy, blood, ectoplasm, spirits, a full moon, purple sky, and drifting
fog. The original embedded **DIRTBOX** world remains the untouched default.
Cycle worlds with `N`; the new world never replaces that startup scene.

The sixth weather state, **Haunted**, brings wisps, shadows, ghosts, the
moonlit sky, fog, and a new procedural eerie sound. It is permanent content,
not a date-limited event.

### Updates without reinstalling

- The **itch app** receives patches through stable butler channels.
- Direct Windows, macOS, and Linux downloads include a built-in updater that
  checks a public manifest, downloads in the background, verifies SHA-256, and
  installs on exit while preserving saves and update settings.
- Press **V** or **Check for updates** to check manually or restart into a
  ready update.
- Hosted browser builds update on reload.

The built-in desktop updater activates when `update-url.txt` contains the real
public manifest URL. See [UPDATES.md](UPDATES.md) for publishing, hosting,
security checks, and update tests.

## Existing sandbox systems

- **100 placeable materials plus the eraser**
- **Six worlds:** DIRTBOX, Volcano, Reef, Laboratory, Skylands, Haunted
- **Six weather states:** Clear, Rain, Snow, Storm, Ashfall, Haunted
- Adjustable wind from `-3` to `+3`
- Draw, line, box, and flood-fill tools
- Circle, square, and spray brushes, sizes 1–7
- 12-snapshot undo history
- Desktop `.dbx` saves and browser-local saves with browser export
- Simulation speeds of 0.25×, 0.5×, 1×, 2×, and 4×, plus pause and single-step
- Machines, electricity, cellular life, chemistry, explosives, and growing things
- Animated powered machinery, emissive glow, reactive skies, and cursor inspector
- Built-in field guide on `H`
- Desktop Discord Rich Presence using local IPC only

## Controls

| Input | Action |
|---|---|
| Left mouse | Use selected tool / draw |
| Right mouse | Freehand erase |
| Middle mouse or `I` | Pick the material under the cursor |
| Mouse wheel over world | Brush size |
| Mouse wheel over material grid | Scroll materials |
| Mouse wheel over category tabs | Cycle category |
| `1`–`9`, `0` | Quick-select a visible material |
| `Tab` / `Shift+Tab` | Next / previous category |
| `T` | Cycle Draw → Line → Box → Fill |
| `B` | Cycle Circle → Square → Spray |
| `[` / `]` | Decrease / increase brush size |
| `Shift` + Box | Filled box instead of an outline |
| `Space` or `P` | Pause / resume |
| `.` | Pause and advance one simulation tick |
| `-` / `=` | Slower / faster simulation |
| `U` or `Ctrl+Z` | Undo |
| `F5` or `Ctrl+S` | Save |
| `F9` or `Ctrl+O` | Load |
| `F2` (browser) | Export the browser save as `dirtbox-world.dbx` |
| `N` / `Shift+N` | Next / previous world |
| `R` | Reset the current world |
| `C` | Clear the world |
| `W` / `Shift+W` | Next / previous weather |
| `A` / `D` | Wind left / right |
| `V` | Check for updates / restart into a ready update |
| `M` | Mute / unmute |
| `H` | Open / close the field guide |
| `F11` | Toggle fullscreen |
| `Esc` | Close guide / cancel a shape / quit |

## Build and test

### Linux

```sh
make -j2 dirtbox updater
./dirtbox
```

The game needs a C++17 compiler and `libsdl2-dev`. The updater helper needs
Go 1.22 or newer only when building it; players do not need Go installed.

### Every regression test

```sh
make test
python3 tools/test_update_e2e.py
```

This runs the original suites, the v3.0 compatibility suite, the v3.1 material
and world suite, and the Go updater tests. The end-to-end update test uses a
loopback server and the real game, with no public hosting.

CMake is also supported for the C++ game and simulation tests:

```sh
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

### macOS

The private GitHub Actions workflow `.github/workflows/macos.yml` installs SDL2
and Go, runs all tests, builds the game and updater, packages `Dirtbox.app`,
bundles SDL2, ad-hoc signs and verifies the app, and uploads
`Dirtbox for macOS.zip` as an artifact.

### Web

```sh
make web      # Arena/CSP-safe JavaScript-only build
make web-wasm # separate embedded-WASM build for normal hosting
```

The regular build is `web-release/index.html` plus `index.js`. The standalone
CSP-safe build is `web-release/Dirtbox.html`, with JavaScript embedded and no
external assets or network requests. It uses Emscripten's `wasm2js` mode so it
also works where WebAssembly is blocked by Content Security Policy.

`make web-wasm` writes `web-wasm-release/Dirtbox-WASM.html` for ordinary hosts
that allow WebAssembly. Keep that file out of the restrictive Arena viewer.

See [BUILD.md](BUILD.md) for Windows, manual web commands, and troubleshooting.

## Discord Rich Presence

Desktop builds connect only to the running Discord desktop app through local
IPC. Activity shows **Dirtbox v3.1**, the current world, particle count or
paused/guide state, and elapsed time. The optional art key is `dirtbox`.
There is no bot, token, SDK, or Discord internet API in the game.

Set `DIRTBOX_NO_DISCORD=1` to disable it or `DIRTBOX_DISCORD_DEBUG=1` for
connection diagnostics. Browser builds do not use Discord Rich Presence.

## Saves and compatibility

- Desktop saves are `dirtbox-world.dbx` in the process working directory.
- Browser saves use `localStorage` under `dirtbox.worldlab.save`; the key is
  retained so existing browser saves continue to work.
- Loading pauses the simulation and creates an undo point first.
- Saves are validated before replacing the current world.
- New material IDs are appended, preserving every older numeric ID.
- Desktop updates never intentionally replace the save or `update-url.txt`.

## Source layout

- `src/sand.cpp`, `src/sand.h` — simulation, reactions, weather, worlds, saves
- `src/default_world.h` — the validated original DIRTBOX world embedded unchanged
- `src/main.cpp` — input, tools, UI, rendering, desktop/web application loop
- `src/updater_bridge.cpp`, `src/updater_bridge.h` — desktop updater integration
- `updater/` — standalone Go updater and its tests
- `src/discord_presence.cpp`, `src/discord_presence.h` — local Discord IPC
- `src/audio.cpp`, `src/audio.h` — procedural sound
- `src/font.cpp`, `src/font.h` — embedded bitmap fonts
- `web/shell.html` — responsive HTML5 shell with save export
- `tools/` — world embedding, standalone HTML, update packaging and tests
- `test_*.cpp` — deterministic simulation regression suites

Dirtbox is maintained as a private project.
