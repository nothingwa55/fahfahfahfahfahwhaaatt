Dirtbox v3.1
Linux x86-64

Run ./run.sh, or run ./dirtbox from this folder.
SDL2 is bundled in lib/ and the executable uses $ORIGIN/lib.
Standard Linux desktop libraries and a compatible glibc are still required.
If the binary does not support your distribution, build from source with make.

The original Dirtbox world is embedded and opens on startup.
RESET or cycling back to DIRTBOX restores it. The Haunted world is separate.
Press N to cycle worlds and W to cycle weather.

Updates:
The itch app updates automatically through its Linux channel.
For direct downloads, the built-in updater activates when update-url.txt beside
the game contains the public manifest URL supplied with the release.
Press V or Check for updates. A downloaded update installs when you exit.
Your dirtbox-world.dbx save and update-url.txt settings are preserved.
Keep dirtbox-updater beside the game.

Discord Rich Presence shows the current world, particle count or paused/guide
state, and elapsed time when the Discord desktop app is running.
Set DIRTBOX_NO_DISCORD=1 to disable it.

Controls:
  Left mouse: draw       Right mouse: erase
  Mouse wheel: brush size
  H: field guide         Space: pause
  N: next world          R: reset
  W: next weather        V: check for updates
  F5 / Ctrl+S: save      F9 / Ctrl+O: load
  F11: fullscreen        Esc: close guide / quit

Saves are written as dirtbox-world.dbx in the current working directory.
The included default-world.dbx is a reference copy; the game does not need it.
